import React, { useState } from 'react';

function CreateWishlist() {
    const [wishlistName, setWishlistName] = useState('');
    const [description, setDescription] = useState('');
    const [errorMessage, setErrorMessage] = useState('');
    const [successMessage, setSuccessMessage] = useState('');
    useEffect(() => {
        fetchWishList();
    }, []);

    const fetchWishList = async () => {
        try {
            const response = await axios.get('http://localhost:8080/category/all');
            setCategories(response.data);
            setShowDeleteButton(response.data.length > 0); // Kategori varsa silme butonunu göster
        } catch (error) {
            console.error('Error fetching categories:', error);
        }
    };

    const handleSubmit = async () => {
        try {
            // Wishlist oluşturma isteği
            const url = 'http://example.com/createwishlist';
    
            const response = await fetch(url, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    wishlistName,
                    description
                })
            });
    
            if (response.ok) {
                const data = await response.json();
                setSuccessMessage(data.message); // Başarılı mesajı ayarlama
                setErrorMessage(''); // Hata mesajını sıfırlama
                setWishlistName(''); // Wishlist adını temizleme
                setDescription(''); // Açıklamayı temizleme
            } else {
                const errorData = await response.json();
                setSuccessMessage(''); // Başarılı mesajı sıfırlama
                setErrorMessage(errorData.error); // Hata mesajını ayarlama
            }
        } catch (error) {
            console.error('Error:', error);
            setSuccessMessage(''); 
            setErrorMessage('Failed to create wishlist'); // Hata mesajını ayarlama
        }
    };
    

    return (
        <div className="w-full max-w-md">
        <ul className="divide-y divide-gray-200">
            {categories.map(category => (
                <li key={category.name} className="py-2 flex items-center justify-between">
                    <span>{category.name}</span>
                    {showDeleteButton && ( // Silme butonunu sadece showDeleteButton true olduğunda göster
                        <button onClick={() => handleWishList(category.name)} className="text-red-600 hover:text-red-800">
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                                <path fillRule="evenodd" d="M14 5a1 1 0 011 1v9a1 1 0 01-1 1H6a1 1 0 01-1-1V6a1 1 0 011-1h8zM7 8a1 1 0 011-1h4a1 1 0 110 2H8a1 1 0 01-1-1zm1 5a1 1 0 00-1 1 1 1 0 001 1h4a1 1 0 100-2H8z" clipRule="evenodd" />
                            </svg>
                        </button>
                    )}
                </li>
            ))}
        </ul>
    </div>
    );
}

export default CreateWishlist;
