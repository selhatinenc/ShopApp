import React, { useState, useEffect } from 'react';
import axios from 'axios';

function PastProductRecommendations() {
    const [recommendations, setRecommendations] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    useEffect(() => {
        fetchRecommendations();
    }, []);

    const fetchRecommendations = async () => {
        try {

            const response = await axios.get('http://localhost:8080/product/recommendations', {
                params: {
                    customerId: 1  }
                });
            setRecommendations(response.data);
            setLoading(false);
        } catch (error) {
            setError('Error fetching recommendations');
            setLoading(false);
            console.error('Error fetching recommendations:', error);
        }
    };

    if (loading) {
        return <div>Loading...</div>;
    }

    if (error) {
        return <div>{error}</div>;
    }

    return (
        <div className="container mx-auto px-4 py-8">
            <div className="text-center mb-8">
                <h2 className="text-3xl font-mono mb-4">List Recommendations</h2>
                <div className="border-b-2 border-gray-400 w-16 mx-auto mb-4"></div>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                {recommendations.map(product => (
                    <div key={product.id} className="bg-white rounded-lg shadow-md overflow-hidden">
                        <img src={product.image || 'placeholder.jpg'} alt={product.name} className="w-full h-48 object-cover object-center" />
                        <div className="p-4">
                            <h3 className="text-lg font-semibold mb-2">{product.name}</h3>
                            <p className="text-gray-600 mb-4">{product.description}</p>
                            <p className="text-gray-800 font-bold">{product.price} TL</p>
                            <p className="text-gray-600">Category: {product.categoryName}</p>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
}

export default PastProductRecommendations;
